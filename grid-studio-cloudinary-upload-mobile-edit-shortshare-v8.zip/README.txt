GRID STUDIO V7 - CLOUDINARY UPLOAD + MOBILE EDIT MODE

New features:
- Existing default feed remains coded into the page and appears automatically.
- No image links are displayed in the interface.
- Upload images button sends selected files directly to your Cloudinary account.
- Cloudinary setup used in the code:
  Cloud name: ddd2jzk7e
  Unsigned upload preset: grid_studio_uploads
- Uploaded images are immediately appended to the grid.
- Copy share link includes current uploaded images and order in the shared URL.
- Mobile starts in safe scrolling mode.
- On mobile, tap Edit to enable moving/deleting posts, then tap Done to return to scrolling.
- X delete and Undo remain included.

Deploy:
1. Unzip this folder.
2. Drag the folder containing index.html into Netlify Drop.
3. Open the published URL.
4. Upload images or rearrange the starting grid.
5. Copy the share link when ready.

Important:
- Uploaded image files stay in Cloudinary.
- The grid order and included image URLs are preserved in the copied share URL.
- If you later change the feed, copy a fresh share link.


V8 CHANGES
- Uploaded Cloudinary images are inserted at the top of the grid, matching a new Instagram post position.
- Copy short link now asks is.gd to create a compact public share link.
- The app caches the last generated short link for the same grid state to avoid unnecessary duplicate shortening requests.
- If is.gd is unavailable or rate limited, the full working preview URL is copied instead.

Shortening service:
- is.gd does not require an API key.
- Links are created only after clicking Copy short link.
